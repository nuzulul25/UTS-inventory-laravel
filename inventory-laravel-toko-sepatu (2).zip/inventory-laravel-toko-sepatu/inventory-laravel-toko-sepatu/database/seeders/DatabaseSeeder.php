<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // 1. Akun Owner
        User::create([
            'name'     => 'Nuzulul Fitri (Owner)',
            'email'    => 'owner@tokosepatu.com',
            'password' => Hash::make('password123'),
            'role'     => 'owner',
        ]);

        // 2. Akun Admin
        User::create([
            'name'     => 'Admin Toko',
            'email'    => 'admin@tokosepatu.com',
            'password' => Hash::make('password123'),
            'role'     => 'admin',
        ]);

        // 3. Akun Staf
        User::create([
            'name'     => 'Staf Gudang',
            'email'    => 'staff@tokosepatu.com',
            'password' => Hash::make('password123'),
            'role'     => 'staff',
        ]);

        // 4. Kategori Produk Sepatu
        $catSneakers = Category::create(['name' => 'Sneakers']);
        $catRunning  = Category::create(['name' => 'Running']);
        $catFormal   = Category::create(['name' => 'Formal']);

        // 5. Data 7 Pasang Produk Sepatu
        Product::create([
            'sku'         => 'SNK-001',
            'name'        => 'Nike Air Force 1',
            'category_id' => $catSneakers->id,
            'price'       => 1500000,
            'stock'       => 10,
        ]);

        Product::create([
            'sku'         => 'SNK-002',
            'name'        => 'Adidas Stan Smith',
            'category_id' => $catSneakers->id,
            'price'       => 1200000,
            'stock'       => 15,
        ]);

        Product::create([
            'sku'         => 'RUN-001',
            'name'        => 'Nike Pegasus 40',
            'category_id' => $catRunning->id,
            'price'       => 2000000,
            'stock'       => 8,
        ]);

        Product::create([
            'sku'         => 'RUN-002',
            'name'        => 'Adidas Ultraboost',
            'category_id' => $catRunning->id,
            'price'       => 2500000,
            'stock'       => 5,
        ]);

        Product::create([
            'sku'         => 'RUN-003',
            'name'        => 'Hoka Clifton 9',
            'category_id' => $catRunning->id,
            'price'       => 2200000,
            'stock'       => 7,
        ]);

        Product::create([
            'sku'         => 'FOR-001',
            'name'        => 'Oxford Leather Shoes',
            'category_id' => $catFormal->id,
            'price'       => 1800000,
            'stock'       => 4,
        ]);

        Product::create([
            'sku'         => 'FOR-002',
            'name'        => 'Loafers Formal Classic',
            'category_id' => $catFormal->id,
            'price'       => 1600000,
            'stock'       => 6,
        ]);
    }
}