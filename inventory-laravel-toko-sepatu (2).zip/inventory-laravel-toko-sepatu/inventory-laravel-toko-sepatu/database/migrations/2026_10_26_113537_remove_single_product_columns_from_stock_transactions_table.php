<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('stock_transactions', function (Blueprint $table) {
            // Cek dan hapus kolom lama jika masih ada agar tidak error
            if (Schema::hasColumn('stock_transactions', 'product_id')) {
                $table->dropForeign(['product_id']);
                $table->dropColumn('product_id');
            }
            if (Schema::hasColumn('stock_transactions', 'quantity')) {
                $table->dropColumn('quantity');
            }
            if (Schema::hasColumn('stock_transactions', 'user_id')) {
                $table->dropColumn('user_id');
            }
        });
    }

    public function down()
    {
        Schema::table('stock_transactions', function (Blueprint $table) {
            $table->unsignedBigInteger('product_id')->nullable();
            $table->integer('quantity')->nullable();
        });
    }
};