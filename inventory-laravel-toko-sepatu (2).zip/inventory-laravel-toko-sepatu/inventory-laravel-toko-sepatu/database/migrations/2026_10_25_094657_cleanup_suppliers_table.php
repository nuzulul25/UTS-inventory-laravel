<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('suppliers', function (Blueprint $table) {
            // Hapus kolom lama yang sudah tidak digunakan lagi
            if (Schema::hasColumn('suppliers', 'nama')) {
                $table->dropColumn('nama');
            }
            if (Schema::hasColumn('suppliers', 'asal')) {
                $table->dropColumn('asal');
            }
            if (Schema::hasColumn('suppliers', 'jumlah_pengiriman')) {
                $table->dropColumn('jumlah_pengiriman');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('suppliers', function (Blueprint $table) {
            $table->string('nama')->nullable();
            $table->string('asal')->nullable();
            $table->string('jumlah_pengiriman')->nullable();
        });
    }
};