

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3">
            <h5 class="mb-0 fw-bold">📦 Riwayat Transaksi Stok Toko Sepatu</h5>
            <a href="<?php echo e(route('stock_transactions.create')); ?>" class="btn btn-light btn-sm fw-bold text-primary">
                <i class="fa fa-plus me-1"></i> Catat Transaksi Baru
            </a>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No. TRX</th>
                            <th>Tanggal</th>
                            <th>Tipe</th>
                            <th>Daftar Produk (Qty)</th>
                            <th>Catatan</th>
                            <th class="text-center" style="width: 150px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-bold">TRX-<?php echo e(str_pad($trx->id, 4, '0', STR_PAD_LEFT)); ?></td>
                            <td><?php echo e($trx->created_at->format('d/m/Y H:i')); ?></td>
                            <td>
                                <?php if($trx->type === 'IN'): ?>
                                    <span class="badge bg-success">MASUK (IN)</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">KELUAR (OUT)</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <ul class="list-unstyled mb-0 small">
                                    <?php $__currentLoopData = $trx->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>• <?php echo e($detail->product->name ?? 'Produk Dihapus'); ?> <strong>(<?php echo e($detail->quantity); ?> pcs)</strong></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td><?php echo e($trx->notes ?? '-'); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('stock_transactions.receipt', $trx->id)); ?>" class="btn btn-info btn-sm text-white" title="Cetak Struk">
                                    <i class="fa fa-print"></i>
                                </a>
                                <form action="<?php echo e(route('stock_transactions.destroy', $trx->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Batalkan transaksi ini dan kembalikan stok?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" title="Batalkan Transaksi">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">Belum ada riwayat transaksi stok.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-laravel-toko-sepatu\inventory-laravel-toko-sepatu\resources\views/stock_transactions/index.blade.php ENDPATH**/ ?>