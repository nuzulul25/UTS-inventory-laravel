

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-dark mb-1">Tambah Supplier Baru</h4>
            <p class="text-muted small mb-0">Masukkan informasi detail pemasok sepatu baru.</p>
        </div>
        <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-secondary btn-sm rounded-2">
            ← Kembali
        </a>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-4">
            <form action="<?php echo e(route('suppliers.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Supplier / Distributor</label>
                    <input type="text" name="name" class="form-control" placeholder="Contoh: PT Nike Indonesia Direct" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">No. Telepon / HP</label>
                    <input type="text" name="phone" class="form-control" placeholder="Contoh: 08123456789">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Alamat</label>
                    <textarea name="address" class="form-control" rows="3" placeholder="Contoh: Jakarta Utara, DKI Jakarta"></textarea>
                </div>

                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-light border">Batal</a>
                    <button type="submit" class="btn btn-primary">Simpan Supplier</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-laravel-toko-sepatu\inventory-laravel-toko-sepatu\resources\views/suppliers/create.blade.php ENDPATH**/ ?>