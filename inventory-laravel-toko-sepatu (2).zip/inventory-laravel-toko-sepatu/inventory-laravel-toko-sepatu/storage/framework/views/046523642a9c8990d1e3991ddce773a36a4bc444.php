

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-header bg-primary text-white py-3">
            <h5 class="mb-0 fw-bold">📦 Catat Transaksi Stok (Multi-Produk & Harga Otomatis)</h5>
        </div>
        <div class="card-body">
            
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('stock_transactions.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Tipe Transaksi Global -->
                <div class="mb-3">
                    <label for="type" class="form-label fw-bold">Tipe Transaksi</label>
                    <select name="type" id="type" class="form-select" required>
                        <option value="IN">Barang Masuk (IN)</option>
                        <option value="OUT">Barang Keluar (OUT / Penjualan)</option>
                    </select>
                </div>

                <!-- Tabel Item Produk -->
                <div class="mb-3">
                    <label class="form-label fw-bold">Daftar Produk</label>
                    <table class="table table-bordered align-middle" id="product-table">
                        <thead class="table-light">
                            <tr>
                                <th>Pilih Produk Sepatu</th>
                                <th style="width: 160px;">Harga Satuan</th>
                                <th style="width: 130px;">Jumlah</th>
                                <th style="width: 160px;">Subtotal</th>
                                <th style="width: 80px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="product-rows">
                            <tr>
                                <td>
                                    <select name="items[0][product_id]" class="form-select product-select" required>
                                        <option value="">-- Pilih Produk --</option>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p->id); ?>" data-price="<?php echo e($p->price); ?>"><?php echo e($p->sku); ?> - <?php echo e($p->name); ?> (Stok: <?php echo e($p->stock); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" class="form-control product-price" readonly placeholder="Rp 0">
                                </td>
                                <td>
                                    <input type="number" name="items[0][quantity]" class="form-control product-qty" min="1" value="1" required>
                                </td>
                                <td>
                                    <input type="text" class="form-control product-subtotal" readonly placeholder="Rp 0">
                                </td>
                                <td class="text-center">
                                    <button type="button" class="btn btn-danger btn-sm remove-row" disabled>
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="button" id="add-row" class="btn btn-success btn-sm">
                        <i class="fa fa-plus me-1"></i> Tambah Baris Produk
                    </button>
                </div>

                <!-- Catatan -->
                <div class="mb-4">
                    <label for="notes" class="form-label fw-bold">Catatan (Opsional)</label>
                    <textarea name="notes" id="notes" class="form-control" rows="3" placeholder="Keterangan tambahan..."></textarea>
                </div>

                <!-- Tombol Aksi -->
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(route('stock_transactions.index')); ?>" class="btn btn-secondary">Kembali</a>
                    <button type="submit" class="btn btn-primary">Simpan Transaksi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Skrip JavaScript untuk Baris Dinamis & Hitung Harga Otomatis -->
<script>
    let rowIndex = 1;

    function formatRupiah(angka) {
        return 'Rp ' + new Intl.NumberFormat('id-ID').format(angka);
    }

    function calculateRow(row) {
        let select = row.querySelector('.product-select');
        let priceInput = row.querySelector('.product-price');
        let qtyInput = row.querySelector('.product-qty');
        let subtotalInput = row.querySelector('.product-subtotal');

        let selectedOption = select.options[select.selectedIndex];
        let price = selectedOption.getAttribute('data-price') ? parseFloat(selectedOption.getAttribute('data-price')) : 0;
        let qty = qtyInput.value ? parseInt(qtyInput.value) : 0;

        priceInput.value = formatRupiah(price);
        subtotalInput.value = formatRupiah(price * qty);
    }

    document.addEventListener('change', function (e) {
        if (e.target.classList.contains('product-select') || e.target.classList.contains('product-qty')) {
            let row = e.target.closest('tr');
            calculateRow(row);
        }
    });

    document.addEventListener('input', function (e) {
        if (e.target.classList.contains('product-qty')) {
            let row = e.target.closest('tr');
            calculateRow(row);
        }
    });

    document.getElementById('add-row').addEventListener('click', function () {
        let tbody = document.getElementById('product-rows');
        let newRow = document.createElement('tr');
        
        newRow.innerHTML = `
            <td>
                <select name="items[${rowIndex}][product_id]" class="form-select product-select" required>
                    <option value="">-- Pilih Produk --</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" data-price="<?php echo e($p->price); ?>"><?php echo e($p->sku); ?> - <?php echo e($p->name); ?> (Stok: <?php echo e($p->stock); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <input type="text" class="form-control product-price" readonly placeholder="Rp 0">
            </td>
            <td>
                <input type="number" name="items[${rowIndex}][quantity]" class="form-control product-qty" min="1" value="1" required>
            </td>
            <td>
                <input type="text" class="form-control product-subtotal" readonly placeholder="Rp 0">
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm remove-row">
                    <i class="fa fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(newRow);
        rowIndex++;
        updateRemoveButtons();
    });

    document.addEventListener('click', function (e) {
        if (e.target && e.target.closest('.remove-row')) {
            e.target.closest('tr').remove();
            updateRemoveButtons();
        }
    });

    function updateRemoveButtons() {
        let rows = document.querySelectorAll('#product-rows tr');
        rows.forEach((row) => {
            let btn = row.querySelector('.remove-row');
            if (rows.length === 1) {
                btn.disabled = true;
            } else {
                btn.disabled = false;
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-laravel-toko-sepatu\inventory-laravel-toko-sepatu\resources\views/stock_transactions/create.blade.php ENDPATH**/ ?>