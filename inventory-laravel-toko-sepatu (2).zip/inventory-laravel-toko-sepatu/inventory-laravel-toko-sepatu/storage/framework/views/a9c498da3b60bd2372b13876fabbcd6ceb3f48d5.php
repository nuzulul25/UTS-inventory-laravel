<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Sepatu - Sistem Inventori</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background-color: #0d6efd; /* sidebar warna biru penuh */
            color: #fff;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 10px 15px;
            border-radius: 6px;
            margin-bottom: 4px;
        }
        .sidebar .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.15);
        }
        .sidebar .nav-link.active {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.25); /* highlight menu aktif */
            font-weight: 600;
        }
        .menu-category {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: rgba(255, 255, 255, 0.7);
            margin-top: 15px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3 d-flex flex-column justify-content-between">
            <div>
                <!-- Header Sidebar -->
                <div class="d-flex align-items-center mb-4 px-3">
                    <span class="fs-2 me-2">👟</span>
                    <div>
                        <div class="fw-bold">Toko Sepatu</div>
                        <small class="text-white-50" style="font-size: 0.75rem;">Sistem Inventori</small>
                    </div>
                </div>

                <!-- Menu Utama -->
                <div class="flex-grow-1 py-2">
                    <div class="menu-category">Menu utama</div>
                    <ul class="nav flex-column">
                        <!-- Dashboard -->
                        <li class="nav-item">
                            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                                <i class="fa fa-home me-2"></i> Dashboard
                            </a>
                        </li>

                        <!-- Data Sepatu (Bisa dilihat Owner, Admin, & Staf Gudang) -->
                        <li class="nav-item">
                            <a href="<?php echo e(route('products.index')); ?>" class="nav-link <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>">
                                <i class="fa fa-box me-2"></i> Data Sepatu
                            </a>
                        </li>

                        <!-- Kategori Sepatu -->
                        <li class="nav-item">
                            <a href="<?php echo e(route('categories.index')); ?>" class="nav-link <?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>">
                                <i class="fa fa-tags me-2"></i> Kategori Sepatu
                            </a>
                        </li>

                        <!-- Supplier (Khusus Owner / Admin) -->
                        <?php if(in_array(auth()->user()->role ?? '', ['owner', 'admin'])): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('suppliers.index')); ?>" class="nav-link <?php echo e(request()->routeIs('suppliers.*') ? 'active' : ''); ?>">
                                <i class="fa fa-truck me-2"></i> Supplier
                            </a>
                        </li>
                        <?php endif; ?>

                        <!-- Transaksi Stok -->
                        <li class="nav-item">
                            <a href="<?php echo e(route('stock_transactions.index')); ?>" class="nav-link <?php echo e(request()->routeIs('stock_transactions.*') ? 'active' : ''); ?>">
                                <i class="fa fa-exchange-alt me-2"></i> Transaksi Stok
                            </a>
                        </li>

                        <!-- Laporan Transaksi Stok (Khusus Owner / Admin) -->
                        <?php if(in_array(auth()->user()->role ?? '', ['owner', 'admin'])): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.index')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>">
                                <i class="fa fa-file-alt me-2"></i> Laporan Transaksi Stok
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <!-- User Info / Logout -->
            <div class="border-top border-white-50 pt-3">
                <div class="d-flex align-items-center mb-3">
                    <div class="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center fw-bold me-2" style="width: 38px; height: 38px;">
                        <?php echo e(strtoupper(substr(auth()->user()->name ?? 'N', 0, 1))); ?>

                    </div>
                    <div class="lh-1">
                        <div class="fw-bold small"><?php echo e(auth()->user()->name ?? 'Nuzulul Fitri'); ?></div>
                        <small class="text-white-50" style="font-size: 0.75rem;">(<?php echo e(strtoupper(auth()->user()->role ?? 'OWNER')); ?>)</small>
                    </div>
                </div>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light btn-sm w-100">Logout</button>
                </form>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-grow-1 p-4">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\inventory-laravel-toko-sepatu\inventory-laravel-toko-sepatu\resources\views/layouts/app.blade.php ENDPATH**/ ?>