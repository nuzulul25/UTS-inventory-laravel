

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-dark mb-1">🏷️ Kategori Sepatu</h4>
            <p class="text-muted small mb-0">Kelola kategori jenis atau merk sepatu.</p>
        </div>
        
        <?php if(in_array(auth()->user()->role ?? '', ['owner', 'admin'])): ?>
        <div>
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary btn-sm rounded-2">
                <i class="fa fa-plus me-1"></i> Tambah Kategori
            </a>
        </div>
        <?php endif; ?>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3" style="width: 50px;">No</th>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            <?php if(in_array(auth()->user()->role ?? '', ['owner', 'admin'])): ?>
                            <th class="text-center" style="width: 120px;">Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-3 fw-bold text-secondary"><?php echo e(($loop->iteration + $categories->firstItem() - 1)); ?></td>
                            <td class="fw-semibold text-dark"><?php echo e($cat->name); ?></td>
                            <td><?php echo e($cat->description ?? '-'); ?></td>
                            
                            <?php if(in_array(auth()->user()->role ?? '', ['owner', 'admin'])): ?>
                            <td class="text-center">
                                <div class="d-flex justify-content-center gap-1">
                                    <a href="<?php echo e(route('categories.edit', $cat->id)); ?>" class="btn btn-warning btn-sm text-white" title="Edit">
                                        <i class="fa fa-pen"></i>
                                    </a>
                                    <form action="<?php echo e(route('categories.destroy', $cat->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus kategori ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e(in_array(auth()->user()->role ?? '', ['owner', 'admin']) ? 4 : 3); ?>" class="text-center py-4 text-muted">
                                Belum ada data kategori sepatu.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-3">
            <?php echo e($categories->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-laravel-toko-sepatu\inventory-laravel-toko-sepatu\resources\views/categories/index.blade.php ENDPATH**/ ?>