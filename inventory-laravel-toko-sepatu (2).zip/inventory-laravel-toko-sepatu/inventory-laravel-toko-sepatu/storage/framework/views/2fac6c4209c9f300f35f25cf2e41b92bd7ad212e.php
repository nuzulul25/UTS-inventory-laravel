

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-2 px-4">
    <!-- Header Selamat Datang Dinamis (Owner / Staf Gudang) -->
    <div class="alert alert-primary border-0 shadow-sm rounded-3 mb-4 text-white" style="background: linear-gradient(135deg, #0d6efd, #0dcaf0);">
        <?php if(auth()->user()->role === 'owner' || auth()->user()->name === 'Nuzulul Fitri'): ?>
            <h4 class="fw-bold mb-1">Selamat Datang Kembali, Nuzulul Fitri! 👋</h4>
            <p class="mb-0 small">Berikut adalah ringkasan inventori dan laporan stok toko sepatu Anda hari ini.</p>
        <?php else: ?>
            <h4 class="fw-bold mb-1">Selamat Datang, Staf Gudang! 👋</h4>
            <p class="mb-0 small">Silakan kelola transaksi dan periksa ketersediaan stok sepatu hari ini.</p>
        <?php endif; ?>
    </div>

    <!-- Baris Kotak Statistik Atas -->
    <div class="row g-3 mb-4">
        <!-- 1. Total Produk -->
        <div class="col-md-4">
            <div class="card border-0 rounded-4 shadow-sm p-3 h-100 bg-white">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted small text-uppercase">TOTAL PRODUK</span>
                    <h3 class="fw-bold text-primary mb-0"><?php echo e($totalProducts ?? 0); ?></h3>
                </div>
                <div class="p-3 bg-primary bg-opacity-10 rounded-3 text-primary">
                    <span class="small"><b>Terdaftar</b> di inventori</span>
                </div>
            </div>
        </div>

        <!-- 2. Stok Rendah -->
        <div class="col-md-4">
            <div class="card border-0 rounded-4 shadow-sm p-3 h-100 bg-white">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted small text-uppercase">STOK RENDAH</span>
                    <h3 class="fw-bold text-warning mb-0"><?php echo e($lowStock ?? 0); ?></h3>
                </div>
                <div class="p-3 bg-warning bg-opacity-10 rounded-3 text-warning">
                    <span class="small">⚠️ <b>Perlu restok</b> segera</span>
                </div>
            </div>
        </div>

        <!-- 3. Total Nilai Aset -->
        <div class="col-md-4">
            <div class="card border-0 rounded-4 shadow-sm p-3 h-100 bg-white">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted small text-uppercase">TOTAL NILAI ASET</span>
                    <h3 class="fw-bold text-success mb-0">Rp <?php echo e(number_format($totalAsset ?? 0, 0, ',', '.')); ?></h3>
                </div>
                <div class="p-3 bg-success bg-opacity-10 rounded-3 text-success">
                    <span class="small">📈 <b>Aset barang</b> aktif</span>
                </div>
            </div>
        </div>
    </div>

    <!-- GRAFIK PENJUALAN & PERGERAKAN STOK -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <h5 class="fw-bold text-dark mb-3">📈 Grafik Perbandingan Barang Masuk & Keluar (Penjualan)</h5>
                <div style="position: relative; height: 320px; width: 100%;">
                    <canvas id="dashboardChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Baris Bawah: Peringatan Stok & Aksi Cepat -->
    <div class="row g-3">
        <!-- Peringatan Stok Menipis -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm p-4 bg-white h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">🔔 Peringatan Stok Menipis</h5>
                    <?php if(in_array(auth()->user()->role ?? '', ['owner', 'admin'])): ?>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">Lihat Semua</a>
                    <?php endif; ?>
                </div>

                <div class="table-responsive">
                    <table class="table table-borderless align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Sepatu</th>
                                <th>Kategori</th>
                                <th class="text-center">Sisa Stok</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-bottom">
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($product->name); ?></div>
                                    <small class="text-muted"><?php echo e($product->code ?? $product->id); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-info bg-opacity-25 text-info-emphasis px-3 py-1">
                                        <?php echo e($product->category->name ?? $product->category ?? 'Sepatu'); ?>

                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-danger rounded-2 px-2 py-1">
                                        <?php echo e($product->stock); ?> pasang
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted py-4">
                                    <i class="fa-solid fa-circle-check text-success me-1"></i> Semua stok produk dalam kondisi aman.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Aksi Cepat Menu -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm p-4 bg-white h-100">
                <h5 class="fw-bold mb-3">⚡ Aksi Cepat Menu</h5>
                <div class="row g-3">
                    <?php if(in_array(auth()->user()->role ?? '', ['owner', 'admin'])): ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('products.index')); ?>" class="text-decoration-none">
                            <div class="card border rounded-3 p-4 bg-light hover-shadow h-100 text-center">
                                <div class="fs-4 text-primary mb-2">📦</div>
                                <h6 class="fw-bold text-dark mb-1">Kelola Data Sepatu</h6>
                                <small class="text-muted">Tambah, edit, atau hapus produk</small>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>

                    <div class="col-md-6">
                        <a href="<?php echo e(route('stock_transactions.index')); ?>" class="text-decoration-none">
                            <div class="card border rounded-3 p-4 bg-light hover-shadow h-100 text-center">
                                <div class="fs-4 text-success mb-2">🔄</div>
                                <h6 class="fw-bold text-dark mb-1">Transaksi Stok</h6>
                                <small class="text-muted">Catat barang masuk & keluar</small>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Muat Skrip Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('dashboardChart').getContext('2d');
        
        // Data dari DashboardController
        const totalIn = <?php echo e($totalIn ?? 0); ?>;
        const totalOut = <?php echo e($totalOut ?? 0); ?>;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Barang Masuk (IN)', 'Barang Keluar (OUT / Penjualan)'],
                datasets: [{
                    label: 'Total Kuantitas Sepatu',
                    data: [totalIn, totalOut],
                    backgroundColor: [
                        'rgba(25, 135, 84, 0.75)',  // Hijau untuk Barang Masuk
                        'rgba(220, 53, 69, 0.75)'   // Merah untuk Barang Keluar / Penjualan
                    ],
                    borderColor: [
                        'rgba(25, 135, 84, 1)',
                        'rgba(220, 53, 69, 1)'
                    ],
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-laravel-toko-sepatu\inventory-laravel-toko-sepatu\resources\views/dashboard.blade.php ENDPATH**/ ?>