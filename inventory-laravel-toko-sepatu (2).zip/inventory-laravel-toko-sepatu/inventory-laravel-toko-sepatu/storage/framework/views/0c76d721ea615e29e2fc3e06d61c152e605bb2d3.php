

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <!-- Header Halaman -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">📊 Laporan Transaksi Stok</h4>
            <p class="text-muted small mb-0">Rekapitulasi keluar masuk barang dan stok toko sepatu.</p>
        </div>
        <div>
            <a href="<?php echo e(route('reports.print', request()->all())); ?>" target="_blank" class="btn btn-success btn-sm fw-bold">
                <i class="fa fa-print me-1"></i> Cetak Laporan
            </a>
        </div>
    </div>

    <!-- Filter Form -->
    <div class="card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('reports.index')); ?>" method="GET" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label for="start_date" class="form-label small fw-bold">Dari Tanggal</label>
                    <input type="date" name="start_date" id="start_date" class="form-control form-control-sm" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label small fw-bold">Sampai Tanggal</label>
                    <input type="date" name="end_date" id="end_date" class="form-control form-control-sm" value="<?php echo e(request('end_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label for="type" class="form-label small fw-bold">Tipe Transaksi</label>
                    <select name="type" id="type" class="form-select form-select-sm">
                        <option value="">Semua Tipe</option>
                        <option value="IN" <?php echo e(request('type') == 'IN' ? 'selected' : ''); ?>>Barang Masuk (IN)</option>
                        <option value="OUT" <?php echo e(request('type') == 'OUT' ? 'selected' : ''); ?>>Barang Keluar (OUT)</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">
                        <i class="fa fa-filter me-1"></i> Filter
                    </button>
                    <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-outline-secondary btn-sm w-100">
                        Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel Data Laporan -->
    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3" style="width: 60px;">No</th>
                            <th>Tanggal</th>
                            <th>No. TRX</th>
                            <th>Nama Produk</th>
                            <th>Tipe</th>
                            <th>Jumlah</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-3"><?php echo e($transactions->firstItem() + $index); ?></td>
                            <td><?php echo e($trx->created_at->format('d/m/Y H:i')); ?></td>
                            <td class="fw-bold text-primary">TRX-<?php echo e(str_pad($trx->id, 4, '0', STR_PAD_LEFT)); ?></td>
                            <td>
                                <ul class="list-unstyled mb-0 small">
                                    <?php $__currentLoopData = $trx->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="py-1 border-bottom border-light">
                                            <?php echo e($detail->product->sku ?? '-'); ?> - <?php echo e($detail->product->name ?? 'Produk Dihapus'); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td>
                                <?php if($trx->type === 'IN'): ?>
                                    <span class="badge bg-success">MASUK (IN)</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">KELUAR (OUT)</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <ul class="list-unstyled mb-0 small">
                                    <?php $__currentLoopData = $trx->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="py-1 border-bottom border-light">
                                            <strong><?php echo e($detail->quantity); ?></strong> pcs
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td><?php echo e($trx->notes ?? '-'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada data laporan transaksi pada rentang tanggal ini.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Pagination -->
        <?php if($transactions->hasPages()): ?>
        <div class="card-footer bg-white py-3">
            <?php echo e($transactions->withQueryString()->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory-laravel-toko-sepatu\inventory-laravel-toko-sepatu\resources\views/reports/index.blade.php ENDPATH**/ ?>