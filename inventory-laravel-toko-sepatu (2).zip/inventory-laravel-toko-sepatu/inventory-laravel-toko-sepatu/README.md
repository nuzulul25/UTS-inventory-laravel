# 👟 Sistem Inventori Toko Sepatu (Laravel Web Application)

Aplikasi web sistem inventori dan manajemen toko sepatu berbasis **Laravel** yang dirancang untuk memudahkan pengelolaan stok barang, data produk, kategori, supplier, customer, serta pencatatan transaksi masuk/keluar secara multi-produk dan terintegrasi dengan laporan penjualan.

---

## ✨ Fitur Utama
1. **Manajemen Produk & Kategori Sepatu**
   - Pengelolaan data sepatu lengkap dengan SKU, harga, stok, dan kategori.
   - Modul kategori sepatu dengan fitur CRUD yang terstruktur.
2. **Transaksi Stok (Multi-Produk & Harga Otomatis)**
   - Pencatatan barang masuk (IN) dan barang keluar / penjualan (OUT) secara multi-item dalam satu transaksi.
   - Penghitungan subtotal dan harga satuan secara otomatis berbasis JavaScript/AJAX.
   - Validasi stok otomatis untuk mencegah transaksi keluar melebihi stok yang tersedia.
3. **Manajemen Supplier & Customer**
   - Pencatatan data pemasok dan pelanggan toko.
4. **Laporan & Rekapitulasi**
   - Rekapitulasi transaksi stok serta laporan penjualan yang terstruktur.
5. **Hak Akses Berbasis Role (Middleware)**
   - **Owner / Admin**: Memiliki hak akses penuh untuk manajemen data (CRUD produk, kategori, supplier), penghapusan transaksi, dan melihat laporan.
   - **Staf Gudang**: Dapat mengakses menu utama, melihat daftar produk, kategori, serta mencatat transaksi stok masuk/keluar.

---

## 🛠️ Teknologi yang Digunakan
- **Backend:** PHP, Laravel Framework
- **Frontend:** Blade Templating, Bootstrap 5, Font Awesome
- **Database:** MySQL / MariaDB
- **Tools:** Composer, Git, VS Code

---

## 📂 Struktur Folder Proyek

Berikut adalah gambaran struktur direktori utama dari aplikasi inventori ini:

```text
inventory-laravel-toko-sepatu/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── CategoryController.php
│   │   │   ├── ProductController.php
│   │   │   ├── StockTransactionController.php
│   │   │   ├── SupplierController.php
│   │   │   └── CustomerController.php
│   │   └── Middleware/
│   └── Models/
│       ├── Category.php
│       ├── Product.php
│       ├── StockTransaction.php
│       └── User.php
├── database/
│   ├── migrations/
│   └── seeders/
├── resources/
│   └── views/
│       ├── categories/
│       ├── products/
│       ├── stock_transactions/
│       └── layouts/
│           └── app.blade.php
├── routes/
│   └── web.php
├── .env.example
├── composer.json
└── README.md

---

## 🚀 Panduan Instalasi Langkah Demi Langkah (Environment Bersih)

Ikuti langkah-langkah berikut untuk menjalankan aplikasi dari awal pada *environment* yang bersih:

1. **Clone Repository / Buka Folder Proyek**
   Pastikan Anda sudah berada di direktori proyek melalui terminal atau command prompt.

2. **Install Dependensi PHP**
   Jalankan perintah berikut untuk menginstal package yang dibutuhkan via Composer:
   ```bash
   composer install