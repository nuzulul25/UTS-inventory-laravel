<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\StockTransactionController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ReportController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('login');
});

// Route Autentikasi / Login / Logout
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Route yang membutuhkan autentikasi
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Route Data Sepatu & Kategori (Dapat dilihat Owner, Admin, & Staf Gudang)
    Route::get('/products', [ProductController::class, 'index'])->name('products.index');
    Route::get('/categories', [CategoryController::class, 'index'])->name('categories.index');

    // Route Transaksi Stok (Multi-Produk: Index, Create, Store, Receipt, & Destroy)
    Route::get('/stock-transactions', [StockTransactionController::class, 'index'])->name('stock_transactions.index');
    Route::get('/stock-transactions/create', [StockTransactionController::class, 'create'])->name('stock_transactions.create');
    Route::post('/stock-transactions', [StockTransactionController::class, 'store'])->name('stock_transactions.store');
    Route::get('/stock-transactions/{id}/receipt', [StockTransactionController::class, 'receipt'])->name('stock_transactions.receipt');
    Route::delete('/stock-transactions/{id}', [StockTransactionController::class, 'destroy'])->name('stock_transactions.destroy');

    // LAPORAN PENJUALAN
    Route::middleware(['role:owner,admin,staf'])->group(function () {
        Route::get('/reports/sales', [ReportController::class, 'index'])->name('reports.index');
        Route::get('/reports/sales/print', [ReportController::class, 'printReport'])->name('reports.print');
    });

    // KHUSUS HAK AKSES OWNER SAJA (Manajemen Data & Hapus Produk/Kategori/Transaksi)
    Route::middleware(['role:owner'])->group(function () {
        Route::delete('/stock-transactions/{id}', [StockTransactionController::class, 'destroy'])->name('stock_transactions.destroy');

        Route::get('/products/create', [ProductController::class, 'create'])->name('products.create');
        Route::post('/products', [ProductController::class, 'store'])->name('products.store');
        Route::get('/products/{product}/edit', [ProductController::class, 'edit'])->name('products.edit');
        Route::put('/products/{product}', [ProductController::class, 'update'])->name('products.update');
        Route::delete('/products/{product}', [ProductController::class, 'destroy'])->name('products.destroy');

        Route::get('/categories/create', [CategoryController::class, 'create'])->name('categories.create');
        Route::post('/categories', [CategoryController::class, 'store'])->name('categories.store');
        Route::get('/categories/{category}/edit', [CategoryController::class, 'edit'])->name('categories.edit');
        Route::put('/categories/{category}', [CategoryController::class, 'update'])->name('categories.update');
        Route::delete('/categories/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');

        Route::resource('suppliers', SupplierController::class);
        Route::resource('customers', CustomerController::class);
    });
});