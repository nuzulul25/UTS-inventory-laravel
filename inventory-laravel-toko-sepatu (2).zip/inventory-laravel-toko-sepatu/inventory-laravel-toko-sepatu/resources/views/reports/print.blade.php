<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Transaksi Stok</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
        }
        @media print {
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body onload="window.print()">

<div class="container my-4">
    <!-- Kop Laporan -->
    <div class="text-center border-bottom pb-3 mb-4">
        <h3 class="fw-bold mb-1">TOKO SEPATU</h3>
        <p class="mb-1 text-muted">Laporan Rekapitulasi Transaksi Stok</p>
        <small class="text-muted">Dicetak pada: {{ date('d/m/Y H:i') }}</small>
    </div>

    <!-- Tabel Data -->
    <table class="table table-bordered align-middle small">
        <thead class="table-dark text-center">
            <tr>
                <th style="width: 50px;">No</th>
                <th>Tanggal</th>
                <th>No. TRX</th>
                <th>Daftar Produk</th>
                <th>Tipe</th>
                <th>Jumlah</th>
                <th>Catatan</th>
            </tr>
        </thead>
        <tbody>
            @forelse($transactions as $index => $trx)
            <tr>
                <td class="text-center">{{ $index + 1 }}</td>
                <td>{{ $trx->created_at->format('d/m/Y H:i') }}</td>
                <td class="fw-bold">TRX-{{ str_pad($trx->id, 4, '0', STR_PAD_LEFT) }}</td>
                <td>
                    <ul class="list-unstyled mb-0">
                        @foreach($trx->details as $detail)
                            <li>• {{ $detail->product->sku ?? '-' }} - {{ $detail->product->name ?? 'Produk Dihapus' }}</li>
                        @endforeach
                    </ul>
                </td>
                <td class="text-center">
                    @if($trx->type === 'IN')
                        <span class="text-success fw-bold">MASUK</span>
                    @else
                        <span class="text-danger fw-bold">KELUAR</span>
                    @endif
                </td>
                <td>
                    <ul class="list-unstyled mb-0">
                        @foreach($trx->details as $detail)
                            <li><strong>{{ $detail->quantity }}</strong> pcs</li>
                        @endforeach
                    </ul>
                </td>
                <td>{{ $trx->notes ?? '-' }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="7" class="text-center text-muted py-3">Tidak ada data transaksi.</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    <!-- Tombol Kembali (Tersembunyi saat diprint) -->
    <div class="text-center mt-4 no-print">
        <a href="{{ route('reports.index') }}" class="btn btn-secondary btn-sm">Kembali ke Laporan</a>
    </div>
</div>

</body>
</html>