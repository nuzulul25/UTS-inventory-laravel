@extends('layouts.app')

@section('content')
<div class="container-fluid py-3 px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fa-solid fa-chart-line text-success me-2"></i> Laporan Penjualan (Barang Keluar)</h2>
        <button onclick="window.print()" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-print me-1"></i> Cetak Laporan
        </button>
    </div>

    <!-- Filter Tanggal -->
    <div class="card border-0 rounded-3 shadow-sm p-3 mb-4 bg-white">
        <form action="{{ route('reports.sales') }}" method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-bold small">Dari Tanggal</label>
                <input type="date" name="start_date" value="{{ request('start_date') }}" class="form-control">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-bold small">Sampai Tanggal</label>
                <input type="date" name="end_date" value="{{ request('end_date') }}" class="form-control">
            </div>
            <div class="col-md-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fa-solid fa-filter me-1"></i> Filter
                </button>
                <a href="{{ route('reports.sales') }}" class="btn btn-outline-secondary w-100">Reset</a>
            </div>
        </form>
    </div>

    <!-- Ringkasan Penjualan -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-0 rounded-3 shadow-sm p-3 bg-success text-white">
                <span class="small text-uppercase fw-bold">Total Barang Terjual</span>
                <h2 class="fw-bold my-1">{{ $totalQuantity }} Pcs</h2>
                <small class="opacity-75">Berdasarkan data filter</small>
            </div>
        </div>
    </div>

    <!-- Tabel Data Penjualan -->
    <div class="card border-0 rounded-3 shadow-sm bg-white p-3">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width: 50px;">No</th>
                        <th>Tanggal Transaksi</th>
                        <th>Nama Produk Sepatu</th>
                        <th>Jumlah Terjual</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($sales as $index => $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->created_at->format('d M Y H:i') }}</td>
                        <td class="fw-bold text-dark">{{ $item->product->name ?? '-' }}</td>
                        <td><span class="badge bg-danger">-{{ $item->quantity }} Pcs</span></td>
                        <td>{{ $item->notes ?? '-' }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            Tidak ada data transaksi penjualan pada periode ini.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection