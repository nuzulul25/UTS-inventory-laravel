<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Transaksi - Toko Sepatu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Courier New', Courier, monospace;
            background-color: #f8f9fa;
        }
        .receipt-box {
            max-width: 450px;
            margin: 30px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        @media print {
            body {
                background: none;
            }
            .no-print {
                display: none !important;
            }
            .receipt-box {
                box-shadow: none;
                margin: 0;
                padding: 0;
                width: 100%;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="receipt-box">
    <!-- Header Toko -->
    <div class="text-center border-bottom pb-3 mb-3">
        <h4 class="fw-bold mb-0">TOKO SEPATU</h4>
        <small class="text-muted">Sistem Inventori & Penjualan</small>
        <p class="mb-0 small text-muted">Jl. Raya Toko Sepatu No. 88</p>
    </div>

    <!-- Informasi Transaksi -->
    <div class="mb-3 small">
        <div class="d-flex justify-content-between">
            <span>No. Transaksi:</span>
            <span class="fw-bold">TRX-{{ str_pad($transaction->id, 4, '0', STR_PAD_LEFT) }}</span>
        </div>
        <div class="d-flex justify-content-between">
            <span>Tanggal:</span>
            <span>{{ $transaction->created_at->format('d/m/Y H:i') }}</span>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-1">
            <span>Tipe:</span>
            @if($transaction->type === 'IN')
                <span class="badge bg-success">BARANG MASUK (IN)</span>
            @else
                <span class="badge bg-danger">BARANG KELUAR (OUT)</span>
            @endif
        </div>
    </div>

    <!-- Daftar Detail Barang (Multi-Produk) -->
    <div class="border-top border-bottom py-2 mb-3">
        @php $grandTotal = 0; @endphp
        @foreach($transaction->details as $detail)
            @php 
                $subtotal = $detail->quantity * ($detail->product->price ?? 0);
                $grandTotal += $subtotal;
            @endphp
            <div class="mb-2 pb-2 border-bottom border-light">
                <div class="fw-bold small">{{ $detail->product->sku ?? '-' }} - {{ $detail->product->name ?? 'Produk Dihapus' }}</div>
                <div class="d-flex justify-content-between small text-muted">
                    <span>{{ $detail->quantity }} pcs x Rp {{ number_format($detail->product->price ?? 0, 0, ',', '.') }}</span>
                    <span class="fw-bold text-dark">
                        Rp {{ number_format($subtotal, 0, ',', '.') }}
                    </span>
                </div>
            </div>
        @endforeach
    </div>

    <!-- Total Pembayaran -->
    <div class="d-flex justify-content-between fw-bold mb-4">
        <span>TOTAL:</span>
        <span class="text-success fs-5">
            Rp {{ number_format($grandTotal, 0, ',', '.') }}
        </span>
    </div>

    <!-- Catatan -->
    @if($transaction->notes)
    <div class="mb-4 small bg-light p-2 rounded">
        <strong>Catatan:</strong> {{ $transaction->notes }}
    </div>
    @endif

    <!-- Footer Struk -->
    <div class="text-center text-muted small border-top pt-3">
        <p class="mb-1">Terima kasih telah berbelanja!</p>
        <p class="mb-0">Barang yang sudah dibeli tidak dapat ditukar.</p>
    </div>

    <!-- Tombol Aksi (Otomatis tersembunyi saat dicetak) -->
    <div class="text-center mt-4 no-print">
        <button onclick="window.print()" class="btn btn-primary btn-sm w-100 mb-2">
            <i class="fa-solid fa-print me-1"></i> Cetak Struk
        </button>
        <a href="{{ route('stock_transactions.index') }}" class="btn btn-outline-secondary btn-sm w-100">
            Kembali ke Transaksi
        </a>
    </div>
</div>

</body>
</html>