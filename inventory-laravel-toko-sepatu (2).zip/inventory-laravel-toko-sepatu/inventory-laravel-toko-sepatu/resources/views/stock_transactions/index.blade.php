@extends('layouts.app')

@section('content')
<div class="container-fluid p-4">
    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3">
            <h5 class="mb-0 fw-bold">📦 Riwayat Transaksi Stok Toko Sepatu</h5>
            <a href="{{ route('stock_transactions.create') }}" class="btn btn-light btn-sm fw-bold text-primary">
                <i class="fa fa-plus me-1"></i> Catat Transaksi Baru
            </a>
        </div>
        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No. TRX</th>
                            <th>Tanggal</th>
                            <th>Tipe</th>
                            <th>Daftar Produk (Qty)</th>
                            <th>Catatan</th>
                            <th class="text-center" style="width: 150px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($transactions as $trx)
                        <tr>
                            <td class="fw-bold">TRX-{{ str_pad($trx->id, 4, '0', STR_PAD_LEFT) }}</td>
                            <td>{{ $trx->created_at->format('d/m/Y H:i') }}</td>
                            <td>
                                @if($trx->type === 'IN')
                                    <span class="badge bg-success">MASUK (IN)</span>
                                @else
                                    <span class="badge bg-danger">KELUAR (OUT)</span>
                                @endif
                            </td>
                            <td>
                                <ul class="list-unstyled mb-0 small">
                                    @foreach($trx->details as $detail)
                                        <li>• {{ $detail->product->name ?? 'Produk Dihapus' }} <strong>({{ $detail->quantity }} pcs)</strong></li>
                                    @endforeach
                                </ul>
                            </td>
                            <td>{{ $trx->notes ?? '-' }}</td>
                            <td class="text-center">
                                <a href="{{ route('stock_transactions.receipt', $trx->id) }}" class="btn btn-info btn-sm text-white" title="Cetak Struk">
                                    <i class="fa fa-print"></i>
                                </a>
                                <form action="{{ route('stock_transactions.destroy', $trx->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Batalkan transaksi ini dan kembalikan stok?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" title="Batalkan Transaksi">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">Belum ada riwayat transaksi stok.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection