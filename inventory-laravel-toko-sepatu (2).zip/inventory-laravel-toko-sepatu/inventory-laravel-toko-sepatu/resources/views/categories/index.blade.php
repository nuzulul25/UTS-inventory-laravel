@extends('layouts.app')

@section('content')
<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-dark mb-1">🏷️ Kategori Sepatu</h4>
            <p class="text-muted small mb-0">Kelola kategori jenis atau merk sepatu.</p>
        </div>
        
        @if(in_array(auth()->user()->role ?? '', ['owner', 'admin']))
        <div>
            <a href="{{ route('categories.create') }}" class="btn btn-primary btn-sm rounded-2">
                <i class="fa fa-plus me-1"></i> Tambah Kategori
            </a>
        </div>
        @endif
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3" style="width: 50px;">No</th>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            @if(in_array(auth()->user()->role ?? '', ['owner', 'admin']))
                            <th class="text-center" style="width: 120px;">Aksi</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($categories as $cat)
                        <tr>
                            <td class="ps-3 fw-bold text-secondary">{{ ($loop->iteration + $categories->firstItem() - 1) }}</td>
                            <td class="fw-semibold text-dark">{{ $cat->name }}</td>
                            <td>{{ $cat->description ?? '-' }}</td>
                            
                            @if(in_array(auth()->user()->role ?? '', ['owner', 'admin']))
                            <td class="text-center">
                                <div class="d-flex justify-content-center gap-1">
                                    <a href="{{ route('categories.edit', $cat->id) }}" class="btn btn-warning btn-sm text-white" title="Edit">
                                        <i class="fa fa-pen"></i>
                                    </a>
                                    <form action="{{ route('categories.destroy', $cat->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus kategori ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                            @endif
                        </tr>
                        @empty
                        <tr>
                            <td colspan="{{ in_array(auth()->user()->role ?? '', ['owner', 'admin']) ? 4 : 3 }}" class="text-center py-4 text-muted">
                                Belum ada data kategori sepatu.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-3">
            {{ $categories->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection