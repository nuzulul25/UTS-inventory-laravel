@extends('layouts.app')

@section('content')
<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-dark mb-1">🚚 Data Supplier Sepatu</h4>
            <p class="text-muted small mb-0">Kelola informasi pemasok, nomor telepon, dan alamat.</p>
        </div>
        <a href="{{ route('suppliers.create') }}" class="btn btn-primary btn-sm rounded-2">
            + Tambah Supplier
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3" style="width: 50px;">No</th>
                            <th>Nama Supplier</th>
                            <th>No. Telepon</th>
                            <th>Alamat</th>
                            <th class="text-center" style="width: 180px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($suppliers as $supplier)
                        <tr>
                            <td class="ps-3 fw-bold text-secondary">{{ $loop->iteration }}</td>
                            <td>
                                <span class="fw-semibold text-dark">{{ $supplier->name }}</span>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border">📞 {{ $supplier->phone ?? '-' }}</span>
                            </td>
                            <td>
                                <span class="text-muted small">{{ $supplier->address ?? '-' }}</span>
                            </td>
                            <td class="text-center">
                                <a href="{{ route('suppliers.edit', $supplier->id) }}" class="btn btn-warning btn-sm text-white me-1">
                                    Edit
                                </a>
                                <form action="{{ route('suppliers.destroy', $supplier->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus supplier ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">Belum ada data supplier.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection