@extends('layouts.app')

@section('content')
<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-dark mb-1">✏️ Edit Data Supplier</h4>
            <p class="text-muted small mb-0">Ubah informasi data pemasok sepatu.</p>
        </div>
        <a href="{{ route('suppliers.index') }}" class="btn btn-secondary btn-sm rounded-2">
            ← Kembali
        </a>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-4">
            <form action="{{ route('suppliers.update', $supplier->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Supplier / Distributor</label>
                    <input type="text" name="nama" class="form-control" value="{{ old('nama', $supplier->nama) }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Asal Pengiriman (Kota/Provinsi)</label>
                    <input type="text" name="asal" class="form-control" value="{{ old('asal', $supplier->asal) }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Jumlah Pengiriman</label>
                    <input type="text" name="jumlah_pengiriman" class="form-control" value="{{ old('jumlah_pengiriman', $supplier->jumlah_pengiriman) }}" required>
                </div>

                <div class="d-flex justify-content-end gap-2 mt-4">
                    <a href="{{ route('suppliers.index') }}" class="btn btn-light border">Batal</a>
                    <button type="submit" class="btn btn-warning text-white">Perbarui Supplier</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection