<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="{{ route('dashboard') }}">Toko Sepatu System</a>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <!-- Dashboard: Semua Role -->
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('dashboard') }}">Dashboard</a>
                </li>

                <!-- Transaksi Stok: Owner, Admin, & Staf -->
                @if(auth()->user()->hasAnyRole(['owner', 'admin', 'staff']))
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('stock_transactions.index') }}">Transaksi Stok</a>
                </li>
                @endif

                <!-- Kelola Produk & Supplier: Owner & Admin -->
                @if(auth()->user()->hasAnyRole(['owner', 'admin']))
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('products.index') }}">Kelola Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('suppliers.index') }}">Supplier</a>
                </li>
                @endif

                <!-- Kelola Pengguna & Laporan Khusus: Hanya Owner -->
                @if(auth()->user()->isOwner())
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('users.index') }}">Kelola User</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('reports.index') }}">Laporan Transaksi Stok</a>
                </li>
                @endif
            </ul>

            <!-- Info Profil & Status Role -->
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                        {{ auth()->user()->name }}
                        <span class="badge bg-info text-dark">{{ strtoupper(auth()->user()->role) }}</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button type="submit" class="dropdown-item">Logout</button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>