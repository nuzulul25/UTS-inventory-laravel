@extends('layouts.app')

@section('content')
<div class="container-fluid p-4">
    <!-- Header Page -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold text-dark mb-1">📦 Data Sepatu</h4>
            <p class="text-muted small mb-0">Kelola daftar produk sepatu dan stok inventori toko.</p>
        </div>
        
        <!-- Tombol Tambah Produk (Hanya Owner / Admin) -->
        @if(in_array(auth()->user()->role ?? '', ['owner', 'admin']))
        <div>
            <a href="{{ route('products.create') }}" class="btn btn-primary btn-sm rounded-2">
                <i class="fa fa-plus me-1"></i> Tambah Produk
            </a>
        </div>
        @endif
    </div>

    <!-- Tabel Produk -->
    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3" style="width: 50px;">No</th>
                            <th>SKU</th>
                            <th>Nama Sepatu</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Status</th>
                            <!-- Kolom Aksi Hanya Muncul untuk Owner / Admin -->
                            @if(in_array(auth()->user()->role ?? '', ['owner', 'admin']))
                            <th class="text-center" style="width: 120px;">Aksi</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($products as $p)
                        <tr>
                            <td class="ps-3 fw-bold text-secondary">{{ ($loop->iteration + $products->firstItem() - 1) }}</td>
                            <td><span class="badge bg-secondary">{{ $p->sku }}</span></td>
                            <td class="fw-semibold text-dark">{{ $p->name }}</td>
                            <td><span class="badge bg-info text-dark">{{ $p->category->name ?? '-' }}</span></td>
                            <td>Rp {{ number_format($p->price, 0, ',', '.') }}</td>
                            <td>
                                <span class="fw-bold {{ $p->stock <= 5 ? 'text-danger' : 'text-success' }}">
                                    {{ $p->stock }} pasang
                                </span>
                            </td>
                            <td>
                                @if($p->stock <= 5)
                                    <span class="badge bg-warning text-dark">Perlu Restok</span>
                                @else
                                    <span class="badge bg-success">Aman</span>
                                @endif
                            </td>
                            
                            <!-- Tombol Edit & Hapus (Hanya Owner / Admin) -->
                            @if(in_array(auth()->user()->role ?? '', ['owner', 'admin']))
                            <td class="text-center">
                                <div class="d-flex justify-content-center gap-1">
                                    <a href="{{ route('products.edit', $p->id) }}" class="btn btn-warning btn-sm text-white" title="Edit">
                                        <i class="fa fa-pen"></i>
                                    </a>
                                    <form action="{{ route('products.destroy', $p->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus produk ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                            @endif
                        </tr>
                        @empty
                        <tr>
                            <td colspan="{{ in_array(auth()->user()->role ?? '', ['owner', 'admin']) ? 8 : 7 }}" class="text-center py-4 text-muted">
                                Belum ada data produk sepatu.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white py-3">
            {{ $products->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection