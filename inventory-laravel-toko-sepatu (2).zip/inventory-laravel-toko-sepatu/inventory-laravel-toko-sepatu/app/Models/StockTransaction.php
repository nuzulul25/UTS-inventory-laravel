<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StockTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'type',
        'notes',
    ];

    /**
     * Relasi ke StockTransactionDetail (Multi-Produk)
     */
    public function details()
    {
        return $this->hasMany(StockTransactionDetail::class, 'stock_transaction_id');
    }
}