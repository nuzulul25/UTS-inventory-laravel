<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  mixed  ...$roles
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        // Pastikan pengguna sudah login
        if (!$request->user()) {
            return redirect()->route('login');
        }

        // Jika parameter dikirim sebagai satu string dipisah koma (contoh: "owner,admin,staf")
        $allowedRoles = [];
        foreach ($roles as $role) {
            $allowedRoles = array_merge($allowedRoles, explode(',', $role));
        }

        // Bersihkan spasi berlebih
        $allowedRoles = array_map('trim', $allowedRoles);

        // Cek apakah role user saat ini ada dalam daftar role yang diizinkan
        if (in_array($request->user()->role, $allowedRoles)) {
            return $next($request);
        }

        // Jika tidak diizinkan, tampilkan error 403
        abort(403, 'AKSES DITOLAK. ANDA TIDAK MEMILIKI IZIN UNTUK MENGAKSES HALAMAN INI.');
    }
}