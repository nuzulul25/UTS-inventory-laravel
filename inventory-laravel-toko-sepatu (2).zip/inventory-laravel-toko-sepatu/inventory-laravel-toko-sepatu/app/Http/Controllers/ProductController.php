<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;

class ProductController extends Controller
{
    // Menampilkan daftar produk (Bisa dilihat oleh Owner, Admin, dan Staf Gudang)
    public function index(Request $request)
    {
        $query = Product::with('category');

        // Pencarian berdasarkan nama atau SKU
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('sku', 'like', "%{$search}%");
            });
        }

        // Filter berdasarkan kategori
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        $products = $query->orderBy('name')->paginate(10)->withQueryString();
        $categories = Category::all();

        return view('products.index', compact('products', 'categories'));
    }

    // Form Tambah Produk (Hanya Owner / Admin)
    public function create()
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $categories = Category::all();
        return view('products.create', compact('categories'));
    }

    // Simpan Produk Baru (Hanya Owner / Admin)
    public function store(Request $request)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'sku'         => 'required|unique:products,sku',
            'name'        => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
        ]);

        Product::create($request->all());

        return redirect()->route('products.index')->with('success', 'Produk sepatu berhasil ditambahkan!');
    }

    // Form Edit Produk (Hanya Owner / Admin)
    public function edit(Product $product)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $categories = Category::all();
        return view('products.edit', compact('product', 'categories'));
    }

    // Update Produk (Hanya Owner / Admin)
    public function update(Request $request, Product $product)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'sku'         => 'required|unique:products,sku,' . $product->id,
            'name'        => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
        ]);

        $product->update($request->all());

        return redirect()->route('products.index')->with('success', 'Produk sepatu berhasil diperbarui!');
    }

    // Hapus Produk (Hanya Owner / Admin)
    public function destroy(Product $product)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $product->delete();

        return redirect()->route('products.index')->with('success', 'Produk sepatu berhasil dihapus!');
    }
}