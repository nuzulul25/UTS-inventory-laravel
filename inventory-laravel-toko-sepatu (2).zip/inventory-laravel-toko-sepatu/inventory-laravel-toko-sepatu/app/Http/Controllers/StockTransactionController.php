<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StockTransaction;
use App\Models\StockTransactionDetail;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

class StockTransactionController extends Controller
{
    // Menampilkan daftar transaksi stok
    public function index(Request $request)
    {
        $transactions = StockTransaction::with('details.product')->latest()->get();
        return view('stock_transactions.index', compact('transactions'));
    }

    // Menampilkan form tambah transaksi
    public function create()
    {
        $products = Product::orderBy('name')->get();
        return view('stock_transactions.create', compact('products'));
    }

    // Menyimpan transaksi multi-produk & update stok otomatis
    public function store(Request $request)
    {
        $request->validate([
            'type'               => 'required|in:IN,OUT',
            'items'              => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity'   => 'required|integer|min:1',
            'notes'              => 'nullable|string|max:255',
        ]);

        try {
            DB::transaction(function () use ($request) {
                // 1. Buat Header Transaksi
                $transaction = StockTransaction::create([
                    'type'  => $request->type,
                    'notes' => $request->notes,
                ]);

                // 2. Simpan Detail & Update Stok Produk
                foreach ($request->items as $item) {
                    $product = Product::findOrFail($item['product_id']);
                    $qty = $item['quantity'];

                    // Validasi stok jika barang keluar (OUT)
                    if ($request->type === 'OUT' && $product->stock < $qty) {
                        throw new \Exception("Stok tidak mencukupi untuk produk: " . $product->name);
                    }

                    StockTransactionDetail::create([
                        'stock_transaction_id' => $transaction->id,
                        'product_id'           => $product->id,
                        'quantity'             => $qty,
                    ]);

                    // Sesuaikan stok
                    if ($request->type === 'IN') {
                        $product->stock += $qty;
                    } else {
                        $product->stock -= $qty;
                    }
                    $product->save();
                }
            });

            return redirect()->route('stock_transactions.index')->with('success', 'Transaksi berhasil disimpan dan stok diperbarui!');

        } catch (\Exception $e) {
            return back()->withInput()->withErrors(['error' => $e->getMessage()]);
        }
    }

    // Menampilkan struk transaksi
    public function receipt($id)
    {
        $transaction = StockTransaction::with('details.product')->findOrFail($id);
        return view('stock_transactions.receipt', compact('transaction'));
    }

    // Menghapus transaksi dan mengembalikan stok
    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                $transaction = StockTransaction::with('details')->findOrFail($id);

                foreach ($transaction->details as $detail) {
                    $product = Product::find($detail->product_id);
                    if ($product) {
                        if ($transaction->type === 'OUT') {
                            $product->stock += $detail->quantity; // Kembalikan stok
                        } else {
                            $product->stock -= $detail->quantity; // Tarik kembali stok masuk
                        }
                        $product->save();
                    }
                }

                $transaction->delete();
            });

            return redirect()->back()->with('success', 'Transaksi berhasil dibatalkan dan stok dikembalikan!');

        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Gagal membatalkan transaksi: ' . $e->getMessage()]);
        }
    }
}