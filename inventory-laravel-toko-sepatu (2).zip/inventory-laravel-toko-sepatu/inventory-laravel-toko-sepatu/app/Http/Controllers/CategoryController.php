<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    // Menampilkan daftar kategori (Bisa dilihat Owner, Admin, & Staf Gudang)
    public function index(Request $request)
    {
        $search = $request->search;
        $categories = Category::when($search, function($query) use ($search) {
            $query->where('name', 'like', "%{$search}%");
        })->orderBy('name')->paginate(10)->withQueryString();

        return view('categories.index', compact('categories'));
    }

    // Form Tambah Kategori (Hanya Owner / Admin)
    public function create()
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }
        return view('categories.create');
    }

    // Simpan Kategori Baru (Hanya Owner / Admin)
    public function store(Request $request)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'name' => 'required|string|max:255|unique:categories,name',
        ]);

        Category::create($request->all());

        return redirect()->route('categories.index')->with('success', 'Kategori sepatu berhasil ditambahkan!');
    }

    public function show($id)
    {
        // Opsional jika diperlukan
    }

    // Form Edit Kategori (Hanya Owner / Admin)
    public function edit(Category $category)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }
        return view('categories.edit', compact('category'));
    }

    // Update Kategori (Hanya Owner / Admin)
    public function update(Request $request, Category $category)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'name' => 'required|string|max:255|unique:categories,name,' . $category->id,
        ]);

        $category->update($request->all());

        return redirect()->route('categories.index')->with('success', 'Kategori sepatu berhasil diperbarui!');
    }

    // Hapus Kategori (Hanya Owner / Admin)
    public function destroy(Category $category)
    {
        if (auth()->user()->role !== 'owner' && auth()->user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $category->delete();

        return redirect()->route('categories.index')->with('success', 'Kategori sepatu berhasil dihapus!');
    }
}