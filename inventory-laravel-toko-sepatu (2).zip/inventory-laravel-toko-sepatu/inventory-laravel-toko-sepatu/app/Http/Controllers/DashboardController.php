<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\StockTransaction;

class DashboardController extends Controller
{
    public function index()
    {
        $totalProducts = Product::count();
        
        // Ambil daftar produk yang stoknya menipis (stok kurang dari atau sama dengan 5)
        $lowStockProducts = Product::where('stock', '<=', 5)->get();
        $lowStock = $lowStockProducts->count();

        // Menghitung nilai total aset
        $totalAsset = Product::all()->sum(function($product) {
            return $product->price * $product->stock;
        });

        // Menghitung total pergerakan stok dari relasi multi-produk (details)
        $totalIn = StockTransaction::where('type', 'IN')
            ->with('details')
            ->get()
            ->sum(function($trx) {
                return $trx->details->sum('quantity');
            });

        $totalOut = StockTransaction::where('type', 'OUT')
            ->with('details')
            ->get()
            ->sum(function($trx) {
                return $trx->details->sum('quantity');
            });

        return view('dashboard', compact(
            'totalProducts',
            'lowStock',
            'lowStockProducts',
            'totalAsset',
            'totalIn',
            'totalOut'
        ));
    }
}