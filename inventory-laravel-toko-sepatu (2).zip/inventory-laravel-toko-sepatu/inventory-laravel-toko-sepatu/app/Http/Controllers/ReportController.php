<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StockTransaction;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        // Mengambil data transaksi dengan relasi multi-produk
        $query = StockTransaction::with(['details.product']);

        if ($request->filled('start_date') && $request->filled('end_date')) {
            $query->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }

        // Filter berdasarkan tipe jika dipilih (IN / OUT)
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        $transactions = $query->latest()->paginate(15);

        return view('reports.index', compact('transactions'));
    }

    public function printReport(Request $request)
    {
        $query = StockTransaction::with(['details.product']);

        if ($request->filled('start_date') && $request->filled('end_date')) {
            $query->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        $transactions = $query->latest()->get();

        return view('reports.print', compact('transactions'));
    }
}